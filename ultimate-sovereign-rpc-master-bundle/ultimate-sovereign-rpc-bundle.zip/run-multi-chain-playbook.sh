#!/bin/bash
ansible-playbook -i inventory.yml deploy-multi-chain.yml